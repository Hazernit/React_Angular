var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
var request = new XMLHttpRequest()

request.open('GET', 'http://api.openweathermap.org/data/2.5/weather?q=Moscow&units=metric&appid=a417a9afcbcad213b77ced6b64f2e589', true)
request.onload = function ()
{
    // Begin accessing JSON data here
    var data = JSON.parse(this.responseText)
    var new_data = JSON.stringify(data)
    console.log(new_data)
    var new_data1 = JSON.parse(new_data)
    let temp_now = new_data1.main.temp
    var feels_like = new_data1.main.feels_like
    var max = new_data1.main.temp_max
    var min = new_data1.main.temp_min
    return temp_now, feels_like, max, min
}
request.open('GET', 'http://api.openweathermap.org/data/2.5/weather?q=Sankt-peterburg&units=metric&appid=a417a9afcbcad213b77ced6b64f2e589', true)
request.onload = function ()
{
    // Begin accessing JSON data here
    var data = JSON.parse(this.responseText)
    var new_data = JSON.stringify(data)
    console.log(new_data)
    var new_data1 = JSON.parse(new_data)
    let temp_now = new_data1.main.temp
    console.log(temp_now)
    var feels_like = new_data1.main.feels_like
    var max = new_data1.main.temp_max
    var min = new_data1.main.temp_min
    return temp_now, feels_like, max, min
}
request.send()